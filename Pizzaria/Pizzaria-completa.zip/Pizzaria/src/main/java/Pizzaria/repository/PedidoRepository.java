package Pizzaria.repository;

import Pizzaria.connection.ConnectionFactory;
import Pizzaria.domain.Cliente;
import Pizzaria.domain.Funcionario;
import Pizzaria.domain.Pedido;
import Pizzaria.domain.Pizza;
import lombok.extern.log4j.Log4j2;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * A relação "Contém" (Pedido N:N Pizza) é tratada aqui, na tabela dbo.Item_Pedido
 * (quantidade, preco_unitario, subtotal, id_pedido, id_pizza) do banco externo.
 * No domínio ela aparece como o atributo item_pedido (List<Pizza>): cada ocorrência da pizza = 1 unidade.
 */
@Log4j2
public class PedidoRepository {

    public static Optional<Pedido> findById(Integer id) {
        log.info("Finding pedido by id '{}'", id);
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = createPreparedStatementFindById(conn, id);
             ResultSet rs = ps.executeQuery()) {
            if (!rs.next()) return Optional.empty();
            Date data = rs.getDate("data_pedido");
            return Optional.of(Pedido.builder()
                    .id_pedido(rs.getInt("id_pedido"))
                    .data_pedido(data == null ? null : data.toLocalDate())
                    .valor_total(rs.getDouble("valor_total"))
                    .status(rs.getString("status"))
                    .forma_pagamento(rs.getString("forma_pagamento"))
                    .id_cliente(Cliente.builder().id_cliente(rs.getInt("id_cliente")).build())
                    .id_funcionario(Funcionario.builder().id_funcionario(rs.getInt("id_funcionario")).build())
                    .item_pedido(findItens(id))
                    .build());
        } catch (SQLException e) {
            log.error("Error while trying to find pedido by id '{}'", id, e);
        }
        return Optional.empty();
    }

    private static PreparedStatement createPreparedStatementFindById(Connection conn, Integer id) throws SQLException {
        String sql = "SELECT * FROM dbo.Pedido WHERE id_pedido = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);
        return ps;
    }

    // Pizzas do pedido (relação "Contém"); repete a pizza conforme a quantidade
    private static List<Pizza> findItens(Integer idPedido) {
        List<Pizza> itens = new ArrayList<>();
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = createPreparedStatementFindItens(conn, idPedido);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Optional<Pizza> pizza = PizzaRepository.findById(rs.getInt("id_pizza"));
                int quantidade = rs.getInt("quantidade");
                pizza.ifPresent(p -> {
                    for (int i = 0; i < quantidade; i++) itens.add(p);
                });
            }
        } catch (SQLException e) {
            log.error("Error while trying to find itens of pedido '{}'", idPedido, e);
        }
        return itens;
    }

    private static PreparedStatement createPreparedStatementFindItens(Connection conn, Integer idPedido) throws SQLException {
        String sql = "SELECT id_pizza, quantidade FROM dbo.Item_Pedido WHERE id_pedido = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, idPedido);
        return ps;
    }

    public static void save(Pedido pedido) {
        log.info("Saving pedido '{}'", pedido);
        try (Connection conn = ConnectionFactory.getConnection()) {
            conn.setAutoCommit(false);
            try {
                Integer idPedido;
                try (PreparedStatement ps = createPreparedStatementSave(conn, pedido)) {
                    ps.execute();
                    idPedido = generatedId(ps);
                }
                saveItens(conn, idPedido, pedido.getItem_pedido());
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            log.error("Error while trying to save pedido", e);
        }
    }

    private static PreparedStatement createPreparedStatementSave(Connection conn, Pedido pedido) throws SQLException {
        String sql = "INSERT INTO dbo.Pedido (data_pedido, valor_total, status, forma_pagamento, id_cliente, id_funcionario) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        fill(ps, pedido);
        return ps;
    }

    public static void delete(Integer id) {
        try (Connection conn = ConnectionFactory.getConnection()) {
            conn.setAutoCommit(false);
            try {
                deleteItens(conn, id);
                try (PreparedStatement ps = createPreparedStatementDelete(conn, id)) {
                    ps.execute();
                }
                conn.commit();
                log.info("Deleted pedido '{}' from the database", id);
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            log.error("Error while trying to delete pedido '{}'", id, e);
        }
    }

    private static PreparedStatement createPreparedStatementDelete(Connection conn, Integer id) throws SQLException {
        String sql = "DELETE FROM dbo.Pedido WHERE id_pedido = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);
        return ps;
    }

    public static void update(Integer id, Pedido pedido) {
        log.info("Updating pedido '{}'", id);
        try (Connection conn = ConnectionFactory.getConnection()) {
            conn.setAutoCommit(false);
            try {
                try (PreparedStatement ps = createPreparedStatementUpdate(conn, id, pedido)) {
                    ps.execute();
                }
                // Só mexe nos itens se a lista foi informada
                if (pedido.getItem_pedido() != null) {
                    deleteItens(conn, id);
                    saveItens(conn, id, pedido.getItem_pedido());
                }
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            log.error("Error while trying to update pedido '{}'", id, e);
        }
    }

    private static PreparedStatement createPreparedStatementUpdate(Connection conn, Integer id, Pedido pedido) throws SQLException {
        String sql = "UPDATE dbo.Pedido SET data_pedido = ?, valor_total = ?, status = ?, forma_pagamento = ?, id_cliente = ?, id_funcionario = ? WHERE id_pedido = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        fill(ps, pedido);
        ps.setInt(7, id);
        return ps;
    }

    // Agrupa as pizzas repetidas em uma linha de Item_Pedido com a quantidade
    private static void saveItens(Connection conn, Integer idPedido, List<Pizza> pizzas) throws SQLException {
        if (pizzas == null) return;
        Map<Integer, Integer> quantidades = new LinkedHashMap<>();
        Map<Integer, Double> precos = new LinkedHashMap<>();
        for (Pizza p : pizzas) {
            quantidades.merge(p.getId_pizza(), 1, Integer::sum);
            precos.putIfAbsent(p.getId_pizza(), p.getPreco() != null
                    ? p.getPreco()
                    : PizzaRepository.findById(p.getId_pizza()).map(Pizza::getPreco).orElse(0.0));
        }
        for (Map.Entry<Integer, Integer> e : quantidades.entrySet()) {
            double preco = precos.get(e.getKey());
            try (PreparedStatement ps = createPreparedStatementSaveItem(conn, idPedido, e.getKey(), e.getValue(), preco)) {
                ps.execute();
            }
        }
    }

    private static PreparedStatement createPreparedStatementSaveItem(Connection conn, Integer idPedido, Integer idPizza, int quantidade, double preco) throws SQLException {
        String sql = "INSERT INTO dbo.Item_Pedido (quantidade, preco_unitario, subtotal, id_pedido, id_pizza) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, quantidade);
        ps.setDouble(2, preco);
        ps.setDouble(3, preco * quantidade);
        ps.setInt(4, idPedido);
        ps.setInt(5, idPizza);
        return ps;
    }

    private static void deleteItens(Connection conn, Integer idPedido) throws SQLException {
        try (PreparedStatement ps = createPreparedStatementDeleteItens(conn, idPedido)) {
            ps.execute();
        }
    }

    private static PreparedStatement createPreparedStatementDeleteItens(Connection conn, Integer idPedido) throws SQLException {
        String sql = "DELETE FROM dbo.Item_Pedido WHERE id_pedido = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, idPedido);
        return ps;
    }

    private static Integer generatedId(PreparedStatement ps) throws SQLException {
        try (ResultSet keys = ps.getGeneratedKeys()) {
            return keys.next() ? keys.getInt(1) : null;
        }
    }

    // Preenche os 6 primeiros parâmetros (usado no INSERT e no UPDATE)
    private static void fill(PreparedStatement ps, Pedido p) throws SQLException {
        ps.setDate(1, Date.valueOf(p.getData_pedido() == null ? java.time.LocalDate.now() : p.getData_pedido()));
        ps.setDouble(2, p.getValor_total());
        ps.setString(3, p.getStatus());
        ps.setString(4, p.getForma_pagamento());
        ps.setInt(5, p.getId_cliente().getId_cliente());
        ps.setInt(6, p.getId_funcionario().getId_funcionario()); // Atende (1,1): obrigatório
    }
}
